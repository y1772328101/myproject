

import tensorflow as tf
from PIL import Image
import numpy as np
import imutils
import cv2
import os

model = tf.keras.models.load_model('./model/model.h5')  # 加载训练好的模型
files = os.listdir('./test/')  # 得到test文件夹文件名称列表


for file in files: #遍历列表中的元素
    image_path = './test/' + file
    img = Image.open(image_path)
    img = img.resize((224, 224))  # 改变图片的大小，使其符合喂入网络的要求
    img = np.array(img).reshape(-1, 224, 224, 3).astype('float32') / 255  # 转成numpy类型数据，归一化处理

    prediction = model.predict(img)  # 调用模型，得到预测结果
    final_prediction = [result.argmax() for result in prediction][0]  # 得到概率最大的超级赛亚人等级的名称
    probability = np.max(prediction)  # 输出结果


    print(probability)
    print(image_path)
    print(['ssg(超赛神)', 'ssgss（超蓝）', 'ssj（超级赛亚人1）', 'ssj2（超级赛亚人2）', 'ssj3（超级赛亚人3）', 'ssj4（超级赛亚人4）'][final_prediction])
    print('--------------')


    image = cv2.imread(image_path)
    image = imutils.resize(image, width=450)
    cv2.imshow('', image)
    cv2.waitKey(0)
