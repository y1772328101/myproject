# 导入工具包
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import pylab as pl
import seaborn as sns

# 导入数据集文件
data = pd.read_csv(
    r'C:\Users\Administrator\Desktop\新建文件夹\ca0b2e71ae0a8934fecec24311cc30b3_25498c385c560b326de44dfa1f088766_8.csv')

# In[] 数据预处理
# 删除第一列无用特征(Order_Number)
data.drop(['Order_Number'], axis=1, inplace=True)  # 删除第一列订单编号
# 销售金额列数据清洗：删除,"w"字眼并根据单位转化
data["Consumption_sum"] = data["Consumption_sum"].map(
    lambda x: (float((x[:-2].replace(",", "")))) * 10000 if "w" in x else (x[:-1].replace(",", "")))
# 转换数据类型
data["Consumption_sum"] = data["Consumption_sum"].astype(float)

# 转换时间格式
data["Sales_Time"] = pd.to_datetime(data["Sales_Time"])
data["Shipment_Time"] = pd.to_datetime(data["Shipment_Time"])

# In[] 缺失值处理
# 查看数据集中的特征缺失情况
plt.rcParams['font.sans-serif'] = ['SimHei']  # 用来正常显示中文标签
plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号
missing = data.isnull().sum().reset_index().rename(columns={0: 'missNum'})
# 计算缺失比例
missing['missRate'] = missing['missNum'] / data.shape[0]
# 按照缺失率排序显示
miss_analy = missing[missing.missRate > 0].sort_values(by='missRate', ascending=False)  # miss_analy 存储的是每个变量缺失情况的数据框
# 柱形图可视化
fig = plt.figure(figsize=(7, 4))
plt.bar(np.arange(miss_analy.shape[0]), list(miss_analy.missRate.values), align='center',
        color=['red', 'green', 'yellow', 'steelblue'])
plt.title('数据集中缺失值特征统计')
plt.xlabel('变量名称')
plt.ylabel('缺失比率')
# 添加x轴标签，并旋转90度
plt.xticks(np.arange(miss_analy.shape[0]), list(miss_analy['index']))
plt.xticks(rotation=0)
# 添加数值显示
for x, y in enumerate(list(miss_analy.missRate.values)):
    plt.text(x, y + 0.00013, '{:.2%}'.format(y), ha='center', rotation=0)
plt.ylim([0, 0.008])
plt.show()

# In[] 对数据集中的Delivery_Status这列离散型变量用众数填补,对Quantity这列连续型变量中的缺失值用均值填补
data['Delivery_Status'].fillna(data['Delivery_Status'].mode()[0], inplace=True)
data['Quantity'].fillna(data['Quantity'].mean(), inplace=True)

# In[] 统计学分析
# 查看销售的货物类型的分布
plt.rcParams['figure.figsize'] = 5, 5
plt.rcParams['figure.dpi'] = 300  # 分辨率
plt.pie(data['Cargostype'].value_counts(), labels=data['Cargostype'].value_counts().index, autopct='%1.2f%%',
        explode=(0.02, 0, 0, 0, 0, 0))
plt.title('Cargostype(1/2/3/4/5/6) Ratio')
plt.show()

# 查看销售地区的分布
plt.rcParams['figure.figsize'] = 5, 5
plt.rcParams['figure.dpi'] = 300  # 分辨率
plt.pie(data['Sales_Territory'].value_counts(), labels=data['Sales_Territory'].value_counts().index, autopct='%1.2f%%',
        explode=(0.02, 0, 0, 0, 0, 0))
plt.title('Sales_Territory Ratio')
plt.show()


# In[] 分析各类货物在不同销售地区的销售情况
def barplot_percentages(feature, orient='v', axis_name="percentage of customers"):
    ratios = pd.DataFrame()
    g = (data.groupby(feature)["Sales_Territory"].value_counts() / len(data)).to_frame()
    g.rename(columns={"Sales_Territory": axis_name}, inplace=True)
    g.reset_index(inplace=True)

    # print(g)
    if orient == 'v':
        fig = plt.figure(figsize=(8, 5))
        ax = sns.barplot(x=feature, y=axis_name, hue='Sales_Territory', data=g, orient=orient)
        ax.set_yticklabels(['{:,.0%}'.format(y) for y in ax.get_yticks()])
        plt.rcParams.update({'font.size': 13})
        # plt.legend(fontsize=10)
    else:
        fig = plt.figure(figsize=(8, 5))
        ax = sns.barplot(x=axis_name, y=feature, hue='Sales_Territory', data=g, orient=orient)
        ax.set_xticklabels(['{:,.0%}'.format(x) for x in ax.get_xticks()])
        plt.legend(fontsize=10)
    plt.title('Sales_Territory Ratio as {0}'.format(feature))
    plt.show()


barplot_percentages("Cargostype")

# In[] 统计不同类型货物的按时交货率和反馈合格率
# 货品和货品交货状况分组计数
data1 = data.groupby(["Cargostype", "Delivery_Status"]).size().unstack()
data1["按时交货率"] = data1["On_Time"] / (data1["On_Time"] + data1["Late"])

# 货品和货品反馈信息分组计数
data2 = data.groupby(["Cargostype", "Feedback"]).size().unstack()
data2['Rejected'].fillna(0, inplace=True)
data2["反馈合格率"] = data2["Qualified"] / (data2["Qualified"] + data2["Rejected"] + data2["Callback"])

# In[] 绘制不同类型货物的按时交货率和反馈合格率
plt.figure(figsize=(8, 5))
plt.plot(data1["按时交货率"], color='b', label='按时交货率')
plt.plot(data2["反馈合格率"], color='r', label='反馈合格率')
plt.xlabel('货物类型', fontsize=20)
plt.ylabel('按时交货率及反馈合格率', fontsize=20)
plt.title('不同类型货物的按时交货率和反馈合格率', fontsize=20)
# 坐标轴字体大小
plt.xticks(fontsize=20)
plt.yticks(fontsize=20)
plt.legend(fontsize=20, loc=4)

# In[] 查看不同月份的按时交货率
# 去除文本前后空格
data["月份"] = data["Sales_Time"].dt.month
data["Delivery_Status"] = data["Delivery_Status"].apply(lambda x: x.strip())
# 以月份和货品交货状况分组统计数量
data1 = data.groupby(["月份", "Delivery_Status"]).size().unstack()
# 求出按时交货率
data1["按时交货率"] = data1["On_Time"] / (data1["On_Time"] + data1["Late"])
plt.figure(figsize=(8, 5))
plt.bar(data1["按时交货率"].index, data1["按时交货率"], align='center', color=['red', 'green', 'yellow', 'steelblue'])
plt.title('不同月份的按时交货率')
plt.xlabel('月份')
plt.ylabel('按时交货率')


# In[] 对离散型变量one_hot编码
# 编码
data.drop(['Sales_Time'], axis=1, inplace=True)
data.drop(['Shipment_Time'], axis=1, inplace=True)
from sklearn.preprocessing import LabelEncoder  # 编码为数字

dtypes_list = data.dtypes.values
columns_list = data.columns
for i in range(len(columns_list)):
    if dtypes_list[i] == 'object':  # 编码为数字
        lb = LabelEncoder()
        lb.fit(data[columns_list[i]])
        data[columns_list[i]] = lb.transform(data[columns_list[i]])
data.head()

# In[] spearman单因素分析查看各变量及标签之间的相关性
corr = data.corr(method='spearman')
import seaborn as sns
import matplotlib.pyplot as plt
from scipy.stats import spearmanr

f, ax = plt.subplots(figsize=(8, 5))
plt.rcParams['figure.dpi'] = 300  # 分辨率
plt.title('Correlation of Numeric Features with Loss', y=1, size=20)
sns.heatmap(corr, square=False, annot=True)  # 热力图

# In[]根据标签按照7:3的比列将数据随机划分为训练集和测试集
from sklearn.model_selection import train_test_split

feature_data = data.loc[:, 'Cargostype':'月份']
target = data['Delivery_Status']
train_X, test_X, train_Y, test_Y = train_test_split(feature_data, target, test_size=0.3, stratify=target,
                                                    random_state=0)

# In[] 构建发货状态是否准时的预测模型
# 随机森林模型
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import precision_score, recall_score, f1_score, confusion_matrix, roc_curve, auc, confusion_matrix, \
    accuracy_score

rf = RandomForestClassifier(max_depth=7, random_state=0)
rf.fit(train_X, train_Y)
# print(feature_names)
# 模型预测
yuce = rf.predict(test_X)
precision = precision_score(test_Y, yuce, average='binary', )
recall = recall_score(test_Y, yuce, average='binary')
f1score = f1_score(test_Y, yuce, average='binary')
accuracy = accuracy_score(test_Y, yuce)
print("Accuracy:", accuracy)
print("Precision:", precision)
print("Recall:", recall)
print("f1_score：", f1score)
# 混淆矩阵
plt.subplots(figsize=(4, 4))
matrix = confusion_matrix(test_Y, yuce)
# create pandas dataframe   创建数据集
dataframe = pd.DataFrame(matrix, index=['Late', 'On_Time'], columns=['Late', 'On_Time'])
# create heatmap 绘制热力图
sns.heatmap(dataframe, annot=True, cmap="Blues", fmt='.5g', square=True)
plt.title('随机森林')
plt.xlabel('predict')
plt.ylabel('true')


# In[] 决策树模型
from sklearn.metrics import precision_score, recall_score, f1_score, confusion_matrix, roc_curve, auc, confusion_matrix, \
    accuracy_score
from sklearn.tree import DecisionTreeClassifier

DT = DecisionTreeClassifier(random_state=0)
DT.fit(train_X, train_Y)
yuce = DT.predict(test_X)
feature_names = [i for i in train_X]
precision = precision_score(test_Y, yuce, average='binary', )
recall = recall_score(test_Y, yuce, average='binary')
f1score = f1_score(test_Y, yuce, average='binary')
accuracy = accuracy_score(test_Y, yuce)
print("Accuracy:", accuracy)
print("Precision:", precision)
print("Recall:", recall)
print("f1_score：", f1score)
plt.subplots(figsize=(4, 4))
matrix = confusion_matrix(test_Y, yuce)
dataframe = pd.DataFrame(matrix, index=['Late', 'On_Time'], columns=['Late', 'On_Time'])
sns.heatmap(dataframe, annot=True, cmap="Blues", fmt='.5g', square=True)
plt.title('决策树')
plt.xlabel('predict')
plt.ylabel('true')

# In[] # 测试集ROC曲线
from sklearn.metrics import roc_auc_score
from sklearn.metrics import roc_curve
import matplotlib.pyplot as plt


def roc_curve_and_score(y_train, pred_proba):
    fpr, tpr, _ = roc_curve(y_train.ravel(), pred_proba.ravel())
    roc_auc = roc_auc_score(y_train.ravel(), pred_proba.ravel())
    return fpr, tpr, roc_auc


plt.figure(figsize=(8, 6))
plt.rcParams.update({'font.size': 14})
plt.grid()

fpr, tpr, roc_auc = roc_curve_and_score(test_Y, rf.predict_proba(test_X)[:, 1])
plt.plot(fpr, tpr, color='b', lw=2,
         label='AUC RF={0:.4f}'.format(roc_auc))

fpr, tpr, roc_auc = roc_curve_and_score(test_Y, DT.predict_proba(test_X)[:, 1])
plt.plot(fpr, tpr, color='r', lw=2,
         label='AUC DT={0:.4f}'.format(roc_auc))

plt.plot([0, 1], [0, 1], color='navy', lw=1, linestyle='--')
plt.legend(loc="lower right")
plt.title('ROC CURVE')
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.0])
plt.xlabel('1 - Specificity')
plt.ylabel('Sensitivity')
plt.show()
