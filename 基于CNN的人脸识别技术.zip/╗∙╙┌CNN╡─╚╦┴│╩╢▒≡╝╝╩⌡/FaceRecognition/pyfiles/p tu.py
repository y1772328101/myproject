# coding:UTF-8
from skimage import io, transform, color
import numpy as np
import cv2
import os
import glob

def convert_gray(f, **args):  # 图片处理与格式化的函数
    rgb = io.imread(f)  # 读取图片
    gray = color.rgb2gray(rgb)  # 将彩色图片转换为灰度图片
    return gray


#最后剪裁的图片大小
size_m = 64
size_n = 64
def detect(img, cascade):
    rects = cascade.detectMultiScale(img, scaleFactor=1.3, minNeighbors=4, minSize=(30, 30),flags=cv2.CASCADE_SCALE_IMAGE)
    if len(rects) == 0:
        return []
    rects[:, 2:] += rects[:, :2]


cascade = cv2.CascadeClassifier("cascades\\haarcascade_frontalface_alt2.xml")
imglist = glob.glob("data/face_my_masked/*")
for list in imglist:

    # print(list)
    # cv2读取图像
    img = cv2.imread(list)
    dst = img
    rects = detect(dst, cascade)
    for x1, y1, x2, y2 in rects:
        # 调整人脸截取的大小。横向为x,纵向为y
        roi = dst[y1 + 10:y2 + 20, x1 + 10:x2]
        img_roi = roi
        re_roi = cv2.resize(img_roi, (size_m, size_n))

        # 新的图像存到data/image/jaffe_1
        f = "{}/{}".format("data/face_my_masked", "jaffe_1")
        # print(f)
        if not os.path.exists(f):
            os.mkdir(f)
        # 切割图像路径
        path = list.split(".")

datapath = r'C:/Users/11353/Desktop/OnlineMaskedFaceRecognition-main/data/face_my_masked_untreated'
str = datapath + '/*.jpg'  # 识别.jpg的图像
coll = io.ImageCollection(str, load_func=convert_gray)  # 批处理
for i in range(len(coll)):
    io.imsave(r'C:/Users/11353/Desktop/OnlineMaskedFaceRecognition-main/data/faces_my_masked' + np.str(i) + '.jpg', coll[i])