

import tensorflow as tf
config = tf.ConfigProto()
config.gpu_options.allow_growth = True
session = tf.Session(config=config)


import tensorflow as tf
from nets import vgg16

EPOCHS = 50  # 训练的轮数
BATCH_SIZE = 2  # 一次喂入神经网络的数据个数
image_height = 224  # 喂入网络图片的高度
image_width = 224  # 喂入网络图片的宽度
model_dir = "./model/model_50.h5"  # 保存模型的位置以及名称
train_dir = "./data/"  # 训练数据集的位置




def get_datasets():  # 准备数据集
    train_datagen = tf.keras.preprocessing.image.ImageDataGenerator(rescale=1.0 / 255.0)  # 归一化处理
    train_generator = train_datagen.flow_from_directory(train_dir,
                                                        target_size=(image_height, image_width),
                                                        color_mode="rgb",  # 色彩
                                                        batch_size=BATCH_SIZE)

    train_num = train_generator.samples  # 得到训练数据集的样本数量
    return train_generator, train_num



def get_model():
    model = vgg16.VGG16()  # 网络的初始化
    model.compile(loss=tf.keras.losses.categorical_crossentropy,  # 损失函数（交叉熵）
                  optimizer=tf.keras.optimizers.Adam(lr=0.00001),  # 优化器的选择，以及学习率的设置
                  metrics=['accuracy'])  # 准确率
    return model  # 返回初始化之后的模型



if __name__ == '__main__':
    train_generator, train_num = get_datasets()  # 调用get_datasets()函数
    model = get_model()  # 得到初始化的模型
    model.summary()  # 输出模型各层的参数状况

    model.fit_generator(train_generator,
                        epochs=EPOCHS,  # 训练次数
                        steps_per_epoch=train_num // BATCH_SIZE)

    model.save(model_dir)  # 模型保存

