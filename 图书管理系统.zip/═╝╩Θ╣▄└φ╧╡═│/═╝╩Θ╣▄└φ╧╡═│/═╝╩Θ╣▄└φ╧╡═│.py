books = [{'name': '芜湖起飞', 'num': '001', 'author': '马老师', 'price': '40', 'shuliang': '2'},
         {'name': '西游记', 'num': '002', 'author': '吴承恩', 'price': '35', 'shuliang': '4'},
         {'name': '赌怪啊', 'num': '003', 'author': '卢本伟', 'price': '29', 'shuliang': '3'},
         {'name': '是观众', 'num': '004', 'author': '老板', 'price': '15', 'shuliang': '3'},
         {'name': '斗破苍穹', 'num': '005', 'author': '土豆', 'price': '9', 'shuliang': '1'}
         ]
users = [{'name': '瓜瓜', 'passwd': '111'}, {'name': '小赵', 'passwd': '111'}, {'name': '小怪兽', 'passwd': '111'}]
import sys


# 主菜单
def menu():
    print('*' * 40)
    print('   ↓*****欢迎来到小Z图书管理系统*****↓')
    print('*' * 40)
    print('    请选择并输入操作号：')
    print("    1: 注册新用户：")
    print("    2. 使用已注册的账号进行登陆：")
    print("    3. 退出本系统")


# 用户页面（功能页面）
def user_menu(self):
    print('*' * 40)
    print('    欢迎%s!   来到“小Z的图书管理系统”' % self)
    print('    请选择并输入操作号：')
    print('    1. 添加书籍')
    print('    2. 删除书籍')
    print('    3. 修改书籍信息')
    print('    4. 查询 | 按书号查询单本书籍信息')
    print('    5. 查询 | 查询所有书籍信息')
    print('    6. 排序 | 按单价排序显示书籍')
    print('    7. 统计 | 按书名统计数量')
    print('    8. 统计 | 按价格区间统计数量')
    print('    9. 残忍退出')


# 注册页面
def sign_up():
    user_name = input("请输入您的用户名：")
    user_passwd = input("请输入您的密码：")
    user_passwd2 = input("请确认您的密码：")
    if user_passwd == user_passwd2:
        user = {'name': user_name, 'passwd': user_passwd}
        users.append(user)
        print("恭喜你！注册成功！")
    else:
        print('咋回事儿啊？再确认下密码就记不住了？')
        print('您还是重新再来一次吧O(∩_∩)O')


# 登陆页面
def login():
    user_name = input("请输入您的用户名：")
    user_passwd = input("请输入您的密码：")
    count = 0
    for i in users:
        if user_name == i['name']:
            count = 1
            if user_passwd == i['passwd']:
                print("嘿嘿嘿，你登陆成功啦！")

                return user_name
            else:
                print("咋回事儿？自己密码不好好记住了？！")
                print("再重新试试吧！")
                login()
    if count == 0:
        print("未查到该用户的信息！")
        print("请重试。")
        login()


# 添加书籍
def add_book():
    book_name = input('请输入要添加书籍的名字：')
    book_author = input('请输入要添加书籍的作者：')
    book_price = input('请输入要添加书籍的价格：')
    book_num = input('请输入要添加书籍的书号：')
    book = {'name': book_name, 'author': book_author, 'price': book_price, 'num': book_num}
    books.append(book)
    print('该书籍信息已成功添加！')


# 删除书籍
def del_book():
    book_name = input('请输入要删除书籍的名字：')
    count = 0
    index = 0
    for i in books:
        if book_name == i['name']:
            count = 1
            del books[index]
            print('该书籍信息已成功删除！')
        index += 1
    if count == 0:
        print('未查到该书籍的信息！')


# 修改书籍
def edit_book():
    book_name = input('请输入要修改书籍的名字：')
    count = 0
    index = 0
    for i in books:
        if book_name == i['name']:
            count = 1
            del books[index]
            new_book_name = input('请输入修改后书籍的名字：')
            new_book_author = input('请输入修改后书籍的作者：')
            new_book_price = input('请输入修改后书籍的价格：')
            new_book_num = input('请输入修改后书籍的书号：')
            new_book = {'name': new_book_name, 'author': new_book_author, 'price': new_book_price, 'num': new_book_num}
            books.append(new_book)
            print('该书籍的信息已完成修改！')
        index += 1
    if count == 0:
        print('未查到该书籍的信息！')


# 按单价排序
def look_price():
    print('书名\t\t作者\t价格\t')
    for i in books:
        sorted(i, key=lambda x: x[2])
        print('[%s]\t%s\t%s\t' % (i['name'], i['author'], i['price']))


# 查看一本书籍
def look_book():
    book_num = input('请输入要查看书籍的书号：')
    count = 0
    print('书名\t\t书号\t\t作者\t\t价格\t')
    for i in books:
        if book_num == i['num']:
            count = 1
            print('%s\t%s\t\t%s\t\t%s\t' % (i['name'], i['num'], i['author'], i['price']))
    if count == 0:
        print('未查到该书籍的信息！')


# 查看全部书籍
def look_books():
    print('书名\t\t书号\t\t作者\t价格\t')
    for i in books:
        print('[%s]\t%s\t\t%s\t\t%s\t' % (i['name'], i['num'], i['author'], i['price']))


# 按书名统计数量
def statistic():
    counts1 = {}
    for i in books:
        if i['name'] in counts1:
            counts1[i['name']] += i['shuliang']
        else:
            counts1[i['name']] = i['shuliang']
    print(counts1)

# 按价格区间统计数量
def statistic_price(index=None):
    count = input('请输入需要统计多少钱以下的书本')
    a=0
    for i in books:
        if i['price'] < count:
            a += 1
            print('[%s]\t\t%s' % (i['name'], i['author']))


# 用户
def while_user(name):
    while name:  # 根据是否登陆成功，进入用户菜单

        if name == 'admin':  # 判断是否为管理者
            print("不好意思，您不是管理员")
            print("请再次选择：")

        else:
            user_menu(name)  # 普通用户页面
            user_n = input()
            if user_n == '1':
                add_book()  # 添加书籍
            elif user_n == '2':
                del_book()  # 删除书籍
            elif user_n == '3':
                edit_book()  # 修改书籍信息
            elif user_n == '4':
                look_book()  # 查询单本书籍信息
            elif user_n == '5':
                look_books()  # 查询所有书籍信息
            elif user_n == '6':
                look_price()  # 按单价排序
            elif user_n == '7':
                statistic()  # 按书名统计数量
            elif user_n == '8':
                statistic_price()  # 按价格区间统计数量
            elif user_n == '9':
                print('您已退出系统！')  #退出
                sys.exit(0)
            else:
                print("不好意思，您的输入有误哦！")
                print("请再次选择：")


# 主函数
def main():
    # 循环菜单主页面
    while True:
        menu()  # 主菜单页面
        menu_n = input()
        if menu_n == '1':
            sign_up()
        elif menu_n == '2':
            # 循环用户菜单页面
            name = login()  # 用户登陆后返回值name
            while_user(name)  # 用户

        else:
            print("不好意思，您的输入有误的嘞！")
            print("请再次选择：")


# 调用主函数
main()
