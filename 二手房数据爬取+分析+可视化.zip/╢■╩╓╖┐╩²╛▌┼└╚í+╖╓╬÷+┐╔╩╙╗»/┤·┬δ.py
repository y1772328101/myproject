# 201906140038 赵丞逸
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
from sklearn.preprocessing import minmax_scale

# 用来正常显示中文标签
plt.rcParams['font.sans-serif'] = ['SimHei']
# 用来正常显示负号
plt.rcParams['axes.unicode_minus'] = False

filename = "ershoufang-clean-utf8-v1.1.csv"

# 数据预处理
# 自定义需要处理的缺失值标记列表
miss_value = ["null", "暂无数据"]
# 数据类型会自动转换
# 使用自定义的列名，跳过文件中的头行，处理缺失值列表标记的缺失值
df = pd.read_csv(filename, na_values=miss_value)
df.info()  # 数据类型

print(df.isnull().sum(axis=0))  # 缺失值检测

df = df.dropna()  # 删除缺失值

# 数据探索及特征分析
print(df.describe())

"""南京各区域二手房平均单价"""
# 特征构建、数据分组、数据运算和聚合
groups_unitprice_area = df["单价(元/平米)"].groupby(df["所在区域"])
mean_unitprice = groups_unitprice_area.mean()
mean_unitprice.index.name = ""

fig = plt.figure(figsize=(12, 7))
ax = fig.add_subplot(111)
ax.set_ylabel("单价(元/平米)", fontsize=14)
ax.set_title("南京各区域二手房平均单价", fontsize=18)
mean_unitprice.plot(kind="bar", fontsize=12)
plt.savefig('mean_price.jpg')
plt.show()

"""南京二手房单价最高Top20"""
unitprice_top = df.sort_values(by="单价(元/平米)", ascending=False)[:20]
unitprice_top = unitprice_top.sort_values(by="单价(元/平米)")
unitprice_top.set_index(unitprice_top["小区名称"], inplace=True)
unitprice_top.index.name = ""

fig = plt.figure(figsize=(12, 7))
ax = fig.add_subplot(111)
ax.set_ylabel("单价(元/平米)", fontsize=14)
ax.set_title("南京二手房单价最高Top20", fontsize=18)
unitprice_top["单价(元/平米)"].plot(kind="barh", fontsize=12)
plt.savefig('price_top20.jpg')
plt.show()

"""南京二手房单价与建筑面积散点图"""
fig = plt.figure(figsize=(12, 7))
ax = fig.add_subplot(111)
ax.set_title("南京二手房单价与建筑面积散点图", fontsize=18)
df.plot(x="建筑面积(㎡)", y="单价(元/平米)", kind="scatter", grid=True, fontsize=12, ax=ax, alpha=0.4,
        xticks=[0, 50, 100, 150, 200, 250, 300, 400, 500, 600, 700], xlim=[0, 800])
ax.set_xlabel("建筑面积(㎡)", fontsize=14)
ax.set_ylabel("单价(元/平米)", fontsize=14)
plt.savefig('price_s.jpg')
plt.show()

# 南京二手房数据词云
def ciyun():
    # 词云
    from wordcloud import WordCloud
    import jieba
    jieba.setLogLevel(jieba.logging.INFO)
    # https://blog.csdn.net/gurentan1911/article/details/112794862 防止报错

    """南京二手房数据词云"""
    savepicture = "南京二手房数据词云.png"
    fontpath = "simhei.ttf"
    stopwords = ["null", "暂无", "数据", "上传", "照片", "房本", "厨", "卫", "室", "厅", "共", "层"]

    # 读入数据文件
    comment_text = open(filename, encoding="utf-8").read()

    # 结巴分词,同时剔除掉不需要的词汇
    ershoufang_words = jieba.cut(comment_text)
    ershoufang_words = [word for word in ershoufang_words if word not in stopwords]
    cut_text = " ".join(ershoufang_words)

    # 设置词云格式
    cloud = WordCloud(
        # 设置字体，不指定就会出现乱码
        font_path=fontpath,
        # 设置背景色
        background_color='white',
        # 词云形状
        # mask=color_mask,
        # 允许最大词汇
        max_words=2000,
        width=800,
        height=600,
        # 最大号字体
        max_font_size=60
    )
    # 产生词云
    word_cloud = cloud.generate(cut_text)
    # 保存图片
    word_cloud.to_file(savepicture)

ciyun()  # 南京二手房数据词云图

# k-means聚类（单价与建筑面积）

# 剔除带有空值的行
df = df.dropna()

# 数据标准化(归一化)
X = df[['单价(元/平米)', '建筑面积(㎡)']]
# X = minmax_scale(x)
# X = pd.DataFrame(X, columns=['SALESTOTAL', 'DIFF_DATE'])
Y = X[:2000]

# 最佳K值确定
K = range(2, 11)
TSSE = []
score = []
for k in K:
    SSE = []
    kmeans = KMeans(n_clusters=k)
    kmeans.fit(Y)
    labels = kmeans.labels_
    centers = kmeans.cluster_centers_  # 类中心
    score.append(silhouette_score(Y, labels))
    for label in set(labels):
        SSE.append(np.sum((X.loc[label == labels] - centers[label, :]) ** 2))
    TSSE.append(np.sum(SSE))
plt.figure(figsize=(10, 5))
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False
plt.subplot(1, 2, 1)
plt.plot(K, TSSE, 'b*-')
plt.xlabel('簇的个数')
plt.ylabel('各簇内离差平方和之和')
plt.show()

# plt.subplot(1, 2, 2)
# plt.plot(K, score, 'ro-')
# plt.xlabel('簇的个数')
# plt.ylabel('轮廓系数')
# plt.show()

# 确定最佳k=5聚类
# 聚类 k=5(直接实现聚类可注销上面确定最佳k代码)
model_kmeans = KMeans(n_clusters=5)
model_kmeans.fit(X)
df['cluster'] = model_kmeans.labels_
for i in range(9):
    plt.scatter(df[df.cluster == i]['建筑面积(㎡)'], df[df.cluster == i]['单价(元/平米)'])
    plt.scatter(df[df.cluster == i]['建筑面积(㎡)'].mean(), df[df.cluster == i]['单价(元/平米)'].mean(), marker='*', c='black',
                s=100)
plt.xlabel('建筑面积(㎡)')
plt.ylabel('单价(元/平米)')
#plt.savefig('单价与建筑面积k-means聚类.jpg')
plt.show()

# 模型评估
from sklearn import metrics

model_kmeans = KMeans(n_clusters=5, random_state=0)  # 建立模型对象
model_kmeans.fit(X)  # 训练聚类模型
y_pre = model_kmeans.predict(X)  # 预测聚类模型
y_true = df['单价(元/平米)']
# 评价指标
inertias = model_kmeans.inertia_  # 样本距离最近的聚类中心的距离总和
mutual_info_s = metrics.mutual_info_score(y_true, y_pre)  # 互信息
homogeneity_s = metrics.homogeneity_score(y_true, y_pre)  # 同质化得分
completeness_s = metrics.completeness_score(y_true, y_pre)  # 完整性得分
v_measure_s = metrics.v_measure_score(y_true, y_pre)  # V-measure得分
print('inertia\\tMI\thomo\tcomp\tv_m')
print('%d\t%.2f\t%.2f\t%.2f\t%.2f' %
      (inertias, mutual_info_s, homogeneity_s,
       completeness_s, v_measure_s))
