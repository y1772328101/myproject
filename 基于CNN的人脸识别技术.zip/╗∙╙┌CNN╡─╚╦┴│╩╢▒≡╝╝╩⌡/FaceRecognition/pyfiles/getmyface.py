import cv2

detector = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')
#VideoCapture()是用于从视频文件、图片序列、摄像头捕获视频的类；
cap =cv2.VideoCapture(0,cv2.CAP_DSHOW)
sampleNum = 0

def raw_input(param):
    pass

Id = raw_input('enter your id: ')


while True:
    ret, img = cap.read()
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    faces = detector.detectMultiScale(gray, 1.3, 5)
    for (x, y, w, h) in faces:
        cv2.rectangle(img, (x, y), (x + w, y + h), (255, 0, 0), 2)


        # 照片样本数递增
        sampleNum = sampleNum + 1

        # 保存照片到MyFace文件夹，照片命名规则为USER+“第几个人”+"照片编号“+jpg后缀
        cv2.imwrite("MyFace/User." + str(Id) + '.' + str(sampleNum) + ".jpg", gray[y:y + h, x:x + w])

        cv2.imshow('frame', img)
    #设置200毫秒拍照延迟
    if cv2.waitKey(500) & 0xFF == ord('q'):
        break
    # 拍下500张照片停止
    elif sampleNum > 30:
        break

cap.release()
cv2.destroyAllWindows()