import pandas as pd

#.csv->.txt
data = pd.read_csv('./us.csv')
with open('./us.txt','a+',encoding='utf-8') as f:
    for line in data.values:
        if pd.isnull(line[3]):
            line[3] = 0
        f.write((str(line[0])+'\t'+str(line[1])+'\t'+str(line[2])+'\t'
                +str(int(line[3]))+'\t'+str(line[4])+'\n'))
